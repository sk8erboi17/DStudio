# Copyright © 2023 Apple Inc.

import argparse

import mlx.core as mx

from .cli_ui import ChatUI
from .generate import stream_generate
from .models.cache import make_prompt_cache
from .sample_utils import make_sampler
from .utils import load, sharded_load

DEFAULT_TEMP = 0.0
DEFAULT_TOP_P = 1.0
DEFAULT_XTC_PROBABILITY = 0.0
DEFAULT_XTC_THRESHOLD = 0.0
DEFAULT_SEED = 0
DEFAULT_MAX_TOKENS = 256
DEFAULT_PREFILL_STEP_SIZE = 2048
DEFAULT_MODEL = "mlx-community/Llama-3.2-3B-Instruct-4bit"


def setup_arg_parser():
    """Set up and return the argument parser."""
    parser = argparse.ArgumentParser(description="Chat with an LLM")
    parser.add_argument(
        "--model",
        type=str,
        help="The path to the local model directory or Hugging Face repo.",
        default=DEFAULT_MODEL,
    )
    parser.add_argument(
        "--trust-remote-code",
        action="store_true",
        help="Enable trusting remote code for tokenizer",
    )
    parser.add_argument(
        "--adapter-path",
        type=str,
        help="Optional path for the trained adapter weights and config.",
    )
    parser.add_argument(
        "--temp", type=float, default=DEFAULT_TEMP, help="Sampling temperature"
    )
    parser.add_argument(
        "--top-p", type=float, default=DEFAULT_TOP_P, help="Sampling top-p"
    )
    parser.add_argument(
        "--xtc-probability",
        type=float,
        default=DEFAULT_XTC_PROBABILITY,
        help="Probability of XTC sampling to happen each next token",
    )
    parser.add_argument(
        "--xtc-threshold",
        type=float,
        default=0.1,
        help="Thresold the probs of each next token candidate to be sampled by XTC",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=DEFAULT_SEED,
        help="PRNG seed",
    )
    parser.add_argument(
        "--max-kv-size",
        type=int,
        help="Set the maximum key-value cache size",
        default=None,
    )
    parser.add_argument(
        "--prefill-step-size",
        type=int,
        default=DEFAULT_PREFILL_STEP_SIZE,
        help="Number of prompt tokens to process at a time. Smaller values "
        f"lower peak memory during prefill (default: {DEFAULT_PREFILL_STEP_SIZE})",
    )
    parser.add_argument(
        "--max-tokens",
        "-m",
        type=int,
        default=DEFAULT_MAX_TOKENS,
        help="Maximum number of tokens to generate",
    )
    parser.add_argument(
        "--system-prompt",
        default=None,
        help="System prompt to be used for the chat template",
    )
    parser.add_argument(
        "--pipeline",
        action="store_true",
        help="Use pipelining instead of tensor parallelism",
    )
    return parser


def main():
    parser = setup_arg_parser()
    args = parser.parse_args()

    group = mx.distributed.init()
    rank = group.rank()
    pipeline_group = group if args.pipeline else None
    tensor_group = group if not args.pipeline else None

    mx.random.seed(args.seed)

    if group.size() > 1:
        if args.adapter_path:
            parser.error("Adapters not supported in distributed mode")
        model, tokenizer = sharded_load(
            args.model,
            pipeline_group,
            tensor_group,
            trust_remote_code=args.trust_remote_code,
        )
    else:
        model, tokenizer = load(
            args.model,
            adapter_path=args.adapter_path,
            tokenizer_config={"trust_remote_code": args.trust_remote_code},
            trust_remote_code=args.trust_remote_code,
        )

    with ChatUI(args, rank=rank) as ui:
        prompt_cache = make_prompt_cache(model, args.max_kv_size)
        while True:
            query = ui.prompt()
            if query == "q":
                ui.say_bye()
                break
            if query == "r":
                prompt_cache = make_prompt_cache(model, args.max_kv_size)
                ui.say_reset()
                continue
            if query == "h":
                ui.say_help()
                continue
            messages = []
            if args.system_prompt is not None:
                messages.append({"role": "system", "content": args.system_prompt})
            messages.append({"role": "user", "content": query})
            prompt = tokenizer.apply_chat_template(
                messages,
                add_generation_prompt=True,
            )
            last_response = None
            for response in stream_generate(
                model,
                tokenizer,
                prompt,
                max_tokens=args.max_tokens,
                sampler=make_sampler(
                    args.temp,
                    args.top_p,
                    xtc_threshold=args.xtc_threshold,
                    xtc_probability=args.xtc_probability,
                    xtc_special_tokens=(
                        tokenizer.encode("\n") + list(tokenizer.eos_token_ids)
                    ),
                ),
                prompt_cache=prompt_cache,
                prefill_step_size=args.prefill_step_size,
            ):
                ui.stream_token(response.text)
                last_response = response
            ui.end_turn(last_response)


if __name__ == "__main__":
    print(
        "Calling `python -m mlx_lm.chat...` directly is deprecated."
        " Use `mlx_lm.chat...` or `python -m mlx_lm chat ...` instead."
    )
    main()
