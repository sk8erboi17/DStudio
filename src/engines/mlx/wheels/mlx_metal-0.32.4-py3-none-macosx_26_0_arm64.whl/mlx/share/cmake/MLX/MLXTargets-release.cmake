#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mlx" for configuration "Release"
set_property(TARGET mlx APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(mlx PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "jaccl::jaccl"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libmlx.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libmlx.dylib"
  )

list(APPEND _cmake_import_check_targets mlx )
list(APPEND _cmake_import_check_files_for_mlx "${_IMPORT_PREFIX}/lib/libmlx.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
