// Copyright © 2025 Apple Inc.

#pragma once

#include "mlx/api.h"

#define MLX_VERSION_MAJOR 0
#define MLX_VERSION_MINOR 32
#define MLX_VERSION_PATCH 3
#define MLX_VERSION_NUMERIC \
  (100000 * MLX_VERSION_MAJOR + 1000 * MLX_VERSION_MINOR + MLX_VERSION_PATCH)

namespace mlx::core {

/* A string representation of the MLX version in the format
 * "major.minor.patch".
 *
 * For dev builds, the version will include the suffix ".devYYYYMMDD+hash"
 */
MLX_API const char* version();

} // namespace mlx::core
